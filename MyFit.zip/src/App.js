import "bootstrap/dist/css/bootstrap.css";
import "../src/utils/Style.css";


import Routers from "./routes";

const App = () => {
 
  return (
    <>
      <Routers />
    </>
  );
};

export default App;
